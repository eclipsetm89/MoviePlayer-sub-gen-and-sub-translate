@echo off
echo Adding C:\ffplay to system PATH...

setx PATH "%PATH%;C:\ffplay" /M

echo.
echo Done.
echo Restart your terminal or programs to use ffmpeg globally.
pause
