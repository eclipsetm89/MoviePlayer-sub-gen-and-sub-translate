@echo off
echo Adding C:\ffprobe to system PATH...

setx PATH "%PATH%;C:\ffprobe" /M

echo.
echo Done.
echo Restart your terminal or programs to use ffmpeg globally.
pause
