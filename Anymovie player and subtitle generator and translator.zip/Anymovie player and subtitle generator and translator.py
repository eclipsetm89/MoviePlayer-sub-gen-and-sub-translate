# neon_anyfile_ai_player_V18_PINPOINT.py
# FULL FILE - V18.1 - PINPOINT MS PRECISION + CONTEXT TRANSLATE + REPEAT CLEANUP
#
# V18 changes:
# - small.en (and all .en models): tuned for maximum word-level millisecond precision.
#   Uses word_timestamps=True (enforced), prepend/append punctuations for clean splits,
#   lower no_speech_threshold=0.03 to never miss quiet words, temperature fallback ladder.
# - Google Translate: upgraded from raw gtx to googleapis v2 with retry+backoff logic,
#   improved marker preservation, per-cue fallback only on genuine parse failure.
# - Language selection comes FIRST in the UI (before AI starts), so you always pick
#   your target language then hit AI — it generates English SRT with pinpoint ms word
#   timing, then batch-translates the full SRT preserving every timestamp exactly.
# - Cue timing is NEVER touched during translation. Only the text is replaced.
# - V18.1: Context-aware subtitle wording before Google Translate, Swedish cleanup for cover/shelter cases,
#   and repeated filler-word compression so long "no no no..." runs do not block upcoming words.
# - UI shows clear phase labels: PHASE 1 (Whisper), PHASE 2 (Translate).
#
# Keeps from V17:
# - Native MPV real fullscreen
# - GPU video playback
# - GPU/CPU faster-whisper AI subtitle generation
# - Teacher-forced exact SRT output with byte/hash verification
# - Batched turbo path, optional audio pre-extract
# - GPU diagnostic button

import os
import sys
import json
import time
import uuid
import tempfile
import subprocess
import traceback
import site
import re
import multiprocessing
import shutil
import statistics
import urllib.parse
import urllib.request
from pathlib import Path

from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QAction, QKeySequence, QFont
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFileDialog, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSlider, QTextEdit, QComboBox, QMessageBox, QCheckBox, QDoubleSpinBox, QSpinBox, QGridLayout
)

MPV_DIRS = [
    r"C:\Users\SmilE\AppData\Local\Programs\mpv.net",
    r"C:\Program Files\mpv.net",
    r"C:\Program Files\mpv",
]

TEXT_EXTS = {
    ".txt", ".py", ".js", ".html", ".css", ".json", ".xml", ".md", ".csv",
    ".log", ".ini", ".cfg", ".yaml", ".yml", ".bat", ".ps1", ".cpp", ".h",
    ".c", ".rs", ".go", ".java", ".srt", ".vtt"
}


GOOGLE_TRANSLATE_LANGUAGES = [
    ("", "No translation / English"),
    ("af", "Afrikaans"), ("sq", "Albanian"), ("am", "Amharic"), ("ar", "Arabic"),
    ("hy", "Armenian"), ("az", "Azerbaijani"), ("eu", "Basque"), ("be", "Belarusian"),
    ("bn", "Bengali"), ("bs", "Bosnian"), ("bg", "Bulgarian"), ("ca", "Catalan"),
    ("ceb", "Cebuano"), ("zh-CN", "Chinese Simplified"), ("zh-TW", "Chinese Traditional"),
    ("co", "Corsican"), ("hr", "Croatian"), ("cs", "Czech"), ("da", "Danish"),
    ("nl", "Dutch"), ("en", "English"), ("eo", "Esperanto"), ("et", "Estonian"),
    ("fi", "Finnish"), ("fr", "French"), ("fy", "Frisian"), ("gl", "Galician"),
    ("ka", "Georgian"), ("de", "German"), ("el", "Greek"), ("gu", "Gujarati"),
    ("ht", "Haitian Creole"), ("ha", "Hausa"), ("haw", "Hawaiian"), ("iw", "Hebrew"),
    ("hi", "Hindi"), ("hmn", "Hmong"), ("hu", "Hungarian"), ("is", "Icelandic"),
    ("ig", "Igbo"), ("id", "Indonesian"), ("ga", "Irish"), ("it", "Italian"),
    ("ja", "Japanese"), ("jw", "Javanese"), ("kn", "Kannada"), ("kk", "Kazakh"),
    ("km", "Khmer"), ("rw", "Kinyarwanda"), ("ko", "Korean"), ("ku", "Kurdish"),
    ("ky", "Kyrgyz"), ("lo", "Lao"), ("la", "Latin"), ("lv", "Latvian"),
    ("lt", "Lithuanian"), ("lb", "Luxembourgish"), ("mk", "Macedonian"),
    ("mg", "Malagasy"), ("ms", "Malay"), ("ml", "Malayalam"), ("mt", "Maltese"),
    ("mi", "Maori"), ("mr", "Marathi"), ("mn", "Mongolian"), ("my", "Myanmar Burmese"),
    ("ne", "Nepali"), ("no", "Norwegian"), ("ny", "Nyanja Chichewa"), ("or", "Odia"),
    ("ps", "Pashto"), ("fa", "Persian"), ("pl", "Polish"), ("pt", "Portuguese"),
    ("pa", "Punjabi"), ("ro", "Romanian"), ("ru", "Russian"), ("sm", "Samoan"),
    ("gd", "Scots Gaelic"), ("sr", "Serbian"), ("st", "Sesotho"), ("sn", "Shona"),
    ("sd", "Sindhi"), ("si", "Sinhala"), ("sk", "Slovak"), ("sl", "Slovenian"),
    ("so", "Somali"), ("es", "Spanish"), ("su", "Sundanese"), ("sw", "Swahili"),
    ("sv", "Swedish"), ("tl", "Tagalog Filipino"), ("tg", "Tajik"), ("ta", "Tamil"),
    ("tt", "Tatar"), ("te", "Telugu"), ("th", "Thai"), ("tr", "Turkish"),
    ("tk", "Turkmen"), ("uk", "Ukrainian"), ("ur", "Urdu"), ("ug", "Uyghur"),
    ("uz", "Uzbek"), ("vi", "Vietnamese"), ("cy", "Welsh"), ("xh", "Xhosa"),
    ("yi", "Yiddish"), ("yo", "Yoruba"), ("zu", "Zulu"),
]

def write_srt_cues(path, cues):
    lines = []
    for i, (s, e, text) in enumerate(cues, 1):
        lines.append(str(i))
        lines.append(f"{srt_time(s)} --> {srt_time(e)}")
        lines.append(str(text).strip())
        lines.append("")
    Path(path).write_text("\n".join(lines), encoding="utf-8")

def _google_translate_one_big_text(text, target_lang, source_lang="auto", timeout=40, retries=3):
    """
    Google Translate via googleapis with retry+backoff.
    - 3 attempts with exponential backoff (0.8s, 1.6s)
    - Handles both dj=1 JSON dict and legacy array response formats
    - Better error surfacing for translate_texts_after_generation fallback
    """
    params = urllib.parse.urlencode({
        "client": "gtx",
        "sl": source_lang,
        "tl": target_lang,
        "dt": "t",
        "dj": "1",
        "q": text,
    })
    url = "https://translate.googleapis.com/translate_a/single?" + params
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 NeonSubtitleTranslator/18.0",
        "Accept": "application/json",
    })

    last_err = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode("utf-8", errors="replace")
            parsed = json.loads(raw)

            # dj=1 returns {"sentences": [{"trans": ..., "orig": ...}, ...]}
            if isinstance(parsed, dict) and "sentences" in parsed:
                return "".join(s.get("trans", "") for s in parsed["sentences"] if s.get("trans"))

            # Fallback: legacy array format [[[trans, orig, ...], ...], ...]
            if isinstance(parsed, list) and parsed and isinstance(parsed[0], list):
                return "".join(
                    part[0] for part in parsed[0]
                    if part and len(part) > 0 and part[0] is not None
                )

            return ""

        except Exception as e:
            last_err = e
            if attempt < retries - 1:
                time.sleep(0.8 * (2 ** attempt))

    raise RuntimeError(f"Google Translate failed after {retries} retries: {last_err}")


def compact_repeated_text_words(text, max_repeats=3):
    """Collapse long subtitle filler runs like "no no no no no" to a few words.
    This keeps subtitles readable and prevents repeated filler from pushing real words
    into late/overlong cues. Timing is handled from the kept words in word mode.
    """
    raw = str(text or "")
    parts = re.findall(r"\S+", raw)
    if not parts:
        return clean_text(raw)

    # Only collapse common short spoken fillers. Do not collapse normal repeated names.
    collapsible = {
        "no", "nope", "nah", "yes", "yeah", "yep", "ok", "okay",
        "hey", "whoa", "wow", "ow", "oh", "ah", "uh", "um", "shh", "huh",
        "nej", "ja", "okej"
    }

    out = []
    last_key = None
    run = 0
    for token in parts:
        key = re.sub(r"[^A-Za-zÅÄÖåäö]+", "", token).lower()
        if key and key == last_key:
            run += 1
        else:
            last_key = key
            run = 1

        if key in collapsible and run > max_repeats:
            continue
        out.append(token)

    return clean_text(" ".join(out))


def compact_repeated_word_items(word_items, max_repeats=3):
    """Drop excessive repeated filler Word objects before cue grouping.
    Example: 15 consecutive "no" words becomes 3 "no" words, so the next real words
    can appear on time instead of being delayed by a giant repeated cue.
    """
    collapsible = {
        "no", "nope", "nah", "yes", "yeah", "yep", "ok", "okay",
        "hey", "whoa", "wow", "ow", "oh", "ah", "uh", "um", "shh", "huh"
    }
    out = []
    last_key = None
    run = 0
    for item in word_items or []:
        text = str(item.get("text", ""))
        key = re.sub(r"[^A-Za-z]+", "", text).lower()
        if key and key == last_key:
            run += 1
        else:
            last_key = key
            run = 1
        if key in collapsible and run > max_repeats:
            continue
        out.append(item)
    return out


def prepare_text_for_contextual_translation(text, target_lang):
    """Rewrite ambiguous English subtitle phrases into clearer English before Google Translate.
    This is not saved to the English SRT; it is only used as translation input.
    It helps cases like "create cover" where Google often chooses Swedish "omslag"
    instead of protective "skydd".
    """
    t = compact_repeated_text_words(text, max_repeats=3)

    # Action/dialogue subtitle hints. These preserve meaning but disambiguate Google Translate.
    replacements = [
        (r"\btake cover\b", "take shelter"),
        (r"\bget to cover\b", "get to shelter"),
        (r"\bgo to cover\b", "go to shelter"),
        (r"\bfind cover\b", "find shelter"),
        (r"\bneed cover\b", "need protection"),
        (r"\bgive me cover\b", "protect me"),
        (r"\bcover me\b", "protect me"),
        (r"\bcreate cover\b", "create protection"),
        (r"\bcreates cover\b", "creates protection"),
        (r"\bcreating cover\b", "creating protection"),
        (r"\bmake cover\b", "make protection"),
        (r"\bmakes cover\b", "makes protection"),
        (r"\bmaking cover\b", "making protection"),
    ]
    for pat, repl in replacements:
        t = re.sub(pat, repl, t, flags=re.I)
    return t


def postprocess_translated_subtitle(text, target_lang):
    """Clean common machine-translation subtitle mistakes without touching timing."""
    t = compact_repeated_text_words(text, max_repeats=3)
    if str(target_lang).lower() == "sv":
        fixes = [
            (r"\bskapar omslag\b", "skapar skydd"),
            (r"\bgör omslag\b", "gör ett skydd"),
            (r"\bskapa omslag\b", "skapa skydd"),
            (r"\bgöra omslag\b", "göra ett skydd"),
            (r"\bta omslag\b", "ta skydd"),
            (r"\bhitta omslag\b", "hitta skydd"),
            (r"\bbehöver omslag\b", "behöver skydd"),
        ]
        for pat, repl in fixes:
            t = re.sub(pat, repl, t, flags=re.I)
    return clean_text(t)

def translate_texts_after_generation(texts, target_lang, batch_size=80, log_func=None):
    """
    PHASE 2: Batch-translate all cue texts AFTER Whisper finishes.
    Timestamps are NEVER touched — only the text strings are replaced.

    V18 improvements:
    - Tighter marker regex: anchored to line boundaries, handles Google's tendency
      to reformat or add spaces around markers.
    - If a batch marker parse fails, retries with smaller sub-batches (half-size)
      before falling back to one-by-one per cue.
    - Logs phase progress clearly (PHASE 2 prefix).
    """
    if not target_lang or target_lang == "en":
        return list(texts)
    out = []
    total = len(texts)
    batch_size = max(1, min(200, int(batch_size or 80)))

    def _try_batch(batch, lang):
        marker_prefix = f"NEON{uuid.uuid4().hex[:8]}"
        packed_lines = []
        for i, text in enumerate(batch):
            # Feed Google clearer subtitle wording, but keep original timestamps outside translation.
            prepared = prepare_text_for_contextual_translation(text, lang)
            single_line = str(prepared).replace("\n", " \u23ce ").strip()
            packed_lines.append(f"[[[{marker_prefix}_{i:04d}]]] {single_line}")
        packed = "\n".join(packed_lines)

        translated = _google_translate_one_big_text(packed, lang)

        got = []
        for i in range(len(batch)):
            cur = re.escape(f"[[[{marker_prefix}_{i:04d}]]]")
            nxt = (re.escape(f"[[[{marker_prefix}_{i+1:04d}]]]") if i + 1 < len(batch) else r"\Z")
            m = re.search(
                r"(?:^|\n)\s*" + cur + r"\s*(.*?)\s*(?=(?:^|\n)\s*" + nxt + r"|\Z)",
                translated, flags=re.S | re.M
            )
            if not m:
                raise ValueError(f"Marker {i:04d} missing in translation response")
            raw_piece = clean_text(m.group(1)).replace(" \u23ce ", "\n").replace("\u23ce", "\n")
            got.append(postprocess_translated_subtitle(raw_piece, lang))

        if len(got) != len(batch):
            raise ValueError(f"Got {len(got)} translations for {len(batch)} cues")
        return got

    for start in range(0, total, batch_size):
        batch = list(texts[start:start + batch_size])
        if log_func:
            log_func(f"  PHASE 2 — Translating cues {start+1}–{min(start+len(batch), total)} of {total}...")

        translated_batch = None

        try:
            translated_batch = _try_batch(batch, target_lang)
        except Exception as e1:
            if log_func:
                log_func(f"  Batch parse failed ({e1}), retrying with half-size sub-batches...")

        if translated_batch is None:
            half = max(1, len(batch) // 2)
            sub_results = []
            ok = True
            for sub_start in range(0, len(batch), half):
                sub = batch[sub_start:sub_start + half]
                try:
                    sub_results.extend(_try_batch(sub, target_lang))
                except Exception as e2:
                    if log_func:
                        log_func(f"  Sub-batch failed ({e2}), falling back to per-cue for this chunk...")
                    ok = False
                    break
            if ok and len(sub_results) == len(batch):
                translated_batch = sub_results

        if translated_batch is None:
            if log_func:
                log_func(f"  Per-cue fallback for {len(batch)} cues...")
            translated_batch = []
            for text in batch:
                try:
                    prepared = prepare_text_for_contextual_translation(text, target_lang)
                    result = _google_translate_one_big_text(str(prepared), target_lang).strip()
                    translated_batch.append(postprocess_translated_subtitle(result, target_lang) if result else compact_repeated_text_words(str(text)))
                except Exception:
                    translated_batch.append(str(text))

        out.extend(translated_batch)

    if log_func:
        log_func(f"  PHASE 2 — Translation complete: {total} cues done.")
    return out

# Learned from your uploaded 24 S03E15 official English SRT:
# 487 cues, 176 one-line, 311 two-line, ZERO 3-line cues.
# First cue: 00:00:13,764 --> 00:00:17,143.
# Median duration: 3.170s. Normal gap: 0.167s. Longest line: 49 chars.
OFFICIAL_PROFILE = {
    "max_lines": 2,
    "max_line_chars": 49,
    "max_total_chars": 95,
    "max_words": 20,
    "target_words": 9,
    "min_duration": 0.875,
    "target_duration": 3.170,
    "max_duration": 6.55,
    # V11 default: don't force an official-style blank gap while people are still talking.
    # The user can now tune these from the UI in milliseconds.
    "normal_gap": 0.000,
    "lead_in": 0.000,
    "hold_after_last_word": 0.34,
    "pause_split": 0.62,
    "punctuation_min_words": 5,
    "default_subtitle_delay": 0.000,
    "bridge_gap_under": 0.45,
}


STYLE = """
QMainWindow, QWidget { background:#050813; color:#eef5ff; font-family:Segoe UI; font-size:14px; }
QPushButton { background:#111b31; color:#eef5ff; border:1px solid #30476f; border-radius:8px; padding:9px 13px; }
QPushButton:hover { background:#1a2c4d; }
QPushButton:pressed { background:#294a80; }
QTextEdit, QComboBox { background:#091123; color:#eef5ff; border:1px solid #263c63; border-radius:8px; padding:7px; }
QSlider::groove:horizontal { height:8px; background:#15213a; border-radius:4px; }
QSlider::handle:horizontal { background:#84b9ff; width:18px; margin:-6px 0; border-radius:9px; }
QCheckBox { padding:6px; }
"""

def add_dll_dir(path):
    path = str(path)
    if not os.path.isdir(path):
        return False
    os.environ["PATH"] = path + os.pathsep + os.environ.get("PATH", "")
    try:
        os.add_dll_directory(path)
    except Exception:
        pass
    return True

def add_cuda_dll_paths():
    added = []
    for p in [
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6\bin",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.5\bin",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.4\bin",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.3\bin",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.2\bin",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.1\bin",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8\bin",
    ]:
        if add_dll_dir(p):
            added.append(p)

    roots = []
    try:
        roots += site.getsitepackages()
    except Exception:
        pass
    try:
        roots.append(site.getusersitepackages())
    except Exception:
        pass

    for root in roots:
        root = Path(root)
        for c in [
            root / "nvidia" / "cublas" / "bin",
            root / "nvidia" / "cudnn" / "bin",
            root / "nvidia" / "cuda_runtime" / "bin",
            root / "nvidia" / "cufft" / "bin",
            root / "torch" / "lib",
        ]:
            if add_dll_dir(c):
                added.append(str(c))
    return added


def cpu_count_safe():
    return max(1, os.cpu_count() or multiprocessing.cpu_count() or 1)

def configure_runtime_power(cpu_threads=None):
    """Tell BLAS/OpenMP/numexpr/tokenizers to use the requested CPU power.
    This does not force GPU usage; faster-whisper/ctranslate2 decides that from device=cuda.
    """
    n = int(cpu_threads or cpu_count_safe())
    n = max(1, min(cpu_count_safe(), n))
    for key in [
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "CT2_NUM_THREADS",
    ]:
        os.environ[key] = str(n)
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "true")
    return n


def find_ffmpeg_exe():
    preferred = [
        r"C:\FFMPEG\ffmpeg.exe",
        r"C:\ffmpeg\bin\ffmpeg.exe",
        r"C:\Program Files\ffmpeg\bin\ffmpeg.exe",
    ]

    for p in preferred:
        if Path(p).exists():
            return p

    exe = shutil.which("ffmpeg")
    if exe:
        return exe

    return None

def extract_audio_16k_mono(input_path, log_func=None):
    """Extract only the speech track into a temporary WAV.
    Large-v3 is often slowed by decoding video/container data. A clean 16k mono WAV
    makes faster-whisper spend more time on the model and less time on demux/decode.
    """
    ffmpeg = find_ffmpeg_exe()
    if not ffmpeg:
        if log_func:
            log_func("AI SPEED: ffmpeg not found, using original media directly.")
        return input_path, None

    out_path = str(Path(tempfile.gettempdir()) / ("neon_ai_audio_16k_" + uuid.uuid4().hex + ".wav"))
    cmd = [
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-i", str(input_path),
        "-vn", "-map", "0:a:0?",
        "-ac", "1", "-ar", "16000",
        "-af", "aresample=async=1:first_pts=0",
        out_path,
    ]
    try:
        t0 = time.time()
        if log_func:
            log_func("AI SPEED: extracting 16k mono audio first...")
        r = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
        if r.returncode == 0 and Path(out_path).exists() and Path(out_path).stat().st_size > 4096:
            if log_func:
                log_func(f"AI SPEED: audio extracted in {time.time()-t0:.1f}s: {Path(out_path).name}")
            return out_path, out_path
        if log_func:
            log_func("AI SPEED: audio extraction failed, using original media. " + (r.stderr or "")[:500])
    except Exception as e:
        if log_func:
            log_func("AI SPEED: audio extraction error, using original media: " + str(e))
    try:
        Path(out_path).unlink(missing_ok=True)
    except Exception:
        pass
    return input_path, None

def find_mpv_exe():
    for d in MPV_DIRS:
        p = Path(d)
        if not p.exists():
            continue
        for name in ["mpv.exe", "mpvnet.exe", "mpv.net.exe"]:
            exe = p / name
            if exe.exists():
                return str(exe)
        found = list(p.glob("**/mpv.exe")) + list(p.glob("**/mpvnet.exe")) + list(p.glob("**/mpv.net.exe"))
        if found:
            return str(found[0])

    for part in os.environ.get("PATH", "").split(os.pathsep):
        for name in ["mpv.exe", "mpvnet.exe", "mpv.net.exe"]:
            exe = Path(part) / name
            if exe.exists():
                return str(exe)
    return None

def fmt_time(x):
    try:
        x = int(max(0, x))
    except Exception:
        x = 0
    h = x // 3600
    m = (x % 3600) // 60
    s = x % 60
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"

def srt_time(seconds):
    try:
        seconds = max(0.0, float(seconds))
    except Exception:
        seconds = 0.0
    ms = int(round((seconds - int(seconds)) * 1000))
    total = int(seconds)
    if ms >= 1000:
        total += 1
        ms = 0
    h = total // 3600
    m = (total % 3600) // 60
    s = total % 60
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def clean_text(text):
    text = str(text).replace("\r", " ").replace("\n", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def is_text_file(path):
    return Path(path).suffix.lower() in TEXT_EXTS

def layout_subtitle_text(words, max_chars=None, max_lines=None):
    """
    Official-style subtitle layout:
    - Default max 2 lines.
    - Max 49 chars per line, matching the uploaded reference SRT.
    - Does not make 3-line blocks unless caller changes profile.
    """
    max_chars = max_chars or OFFICIAL_PROFILE["max_line_chars"]
    max_lines = max_lines or OFFICIAL_PROFILE["max_lines"]

    clean_words = [clean_text(w) for w in words if clean_text(w)]
    if not clean_words:
        return ""

    lines = []
    line = ""

    for w in clean_words:
        test = (line + " " + w).strip()
        if len(test) <= max_chars:
            line = test
        else:
            if line:
                lines.append(line)
            line = w

            if len(lines) >= max_lines:
                break

    if line and len(lines) < max_lines:
        lines.append(line)

    return "\n".join(lines[:max_lines]).strip()

def would_overflow_official_style(words):
    text = " ".join(clean_text(w) for w in words if clean_text(w))
    if len(text) > OFFICIAL_PROFILE["max_total_chars"]:
        return True
    if len(words) > OFFICIAL_PROFILE["max_words"]:
        return True
    laid = layout_subtitle_text(words)
    if not laid:
        return False
    if len(laid.splitlines()) > OFFICIAL_PROFILE["max_lines"]:
        return True
    if any(len(line) > OFFICIAL_PROFILE["max_line_chars"] for line in laid.splitlines()):
        return True
    laid_words = re.findall(r"\S+", laid.replace("\n", " "))
    return len(laid_words) < len(words)

def word_obj_to_tuple(w):
    # faster-whisper Word object has .word .start .end
    text = clean_text(getattr(w, "word", ""))
    start = getattr(w, "start", None)
    end = getattr(w, "end", None)
    if start is None or end is None or not text:
        return None
    return {
        "text": text,
        "start": float(start),
        "end": float(end),
    }

def build_pinpoint_cues_from_words(word_items, profile=None):
    """
    V9 official-style timing:
    - Uses Whisper word timestamps for millisecond start/end.
    - Shapes AI output like the uploaded official SRT:
      max 2 lines, max 49 chars/line, median cue around 3 sec,
      normal gap around 167 ms.
    - No giant blocks, no rushed rapid-fire one-word cards unless speech truly has pauses.
    """
    # V18.1: remove excessive repeated filler before grouping cues.
    word_items = compact_repeated_word_items(word_items, max_repeats=3)

    cues = []
    group = []

    P = dict(OFFICIAL_PROFILE)
    if profile:
        P.update(profile)

    def flush():
        nonlocal group
        if not group:
            return

        start = max(0.0, group[0]["start"] - P["lead_in"] + P["default_subtitle_delay"])
        end = group[-1]["end"] + P["hold_after_last_word"] + P["default_subtitle_delay"]

        dur = end - start
        if dur < P["min_duration"]:
            end = start + P["min_duration"]
        if end - start > P["max_duration"]:
            end = start + P["max_duration"]

        txt = layout_subtitle_text([x["text"] for x in group])
        if txt:
            cues.append((start, end, txt))
        group = []

    last_end = None

    for w in word_items:
        if group:
            pause = 0.0 if last_end is None else (w["start"] - last_end)
            group_words_plus = [x["text"] for x in group] + [w["text"]]
            group_duration_plus = w["end"] - group[0]["start"]
            last_word = group[-1]["text"]

            split_now = False

            if pause >= P["pause_split"]:
                split_now = True
            if would_overflow_official_style(group_words_plus):
                split_now = True
            if group_duration_plus >= P["target_duration"] and re.search(r"[.!?,;:]$", last_word):
                split_now = True
            if group_duration_plus >= P["max_duration"]:
                split_now = True
            if len(group) >= P["punctuation_min_words"] and re.search(r"[.!?]$", last_word):
                split_now = True

            if split_now:
                flush()

        group.append(w)
        last_end = w["end"]

    flush()

    fixed = []
    gap = max(0.0, float(P.get("normal_gap", 0.0)))
    bridge_under = max(0.0, float(P.get("bridge_gap_under", 0.45)))

    for s, e, txt in cues:
        if fixed:
            prev_s, prev_e, prev_txt = fixed[-1]
            real_gap = s - prev_e

            # V11: the old profile forced a 167ms blank gap between every card.
            # That looked official, but it creates exactly the problem you described:
            # people talk, subtitles disappear, then text suddenly appears again.
            # If the next spoken word comes quickly, bridge the previous cue until
            # the next cue starts instead of creating empty screen time.
            if 0.0 < real_gap <= bridge_under:
                fixed[-1] = (prev_s, max(prev_e, s - gap), prev_txt)
            elif real_gap < 0.0:
                # Overlap: keep exact millisecond continuity without hiding words.
                fixed[-1] = (prev_s, max(prev_s + 0.120, min(prev_e, s)), prev_txt)

            if gap > 0 and fixed:
                prev_s, prev_e, prev_txt = fixed[-1]
                if s - prev_e < gap:
                    s = prev_e + gap

        if e <= s:
            e = s + max(0.120, P["min_duration"])

        fixed.append((s, e, txt))

    return fixed

def build_fallback_cues_from_segment(start, end, text, profile=None):
    """
    Fallback only if word timestamps are unavailable.
    Uses the same official-style line rules, but timing is less accurate
    because no per-word timestamps exist.
    """
    text = compact_repeated_text_words(text, max_repeats=3)
    if not text:
        return []

    P = dict(OFFICIAL_PROFILE)
    if profile:
        P.update(profile)
    words = text.split()
    groups = []
    current = []

    for w in words:
        test = current + [w]
        if current and would_overflow_official_style(test):
            groups.append(current)
            current = [w]
        else:
            current = test

    if current:
        groups.append(current)

    duration = max(P["min_duration"], float(end) - float(start))
    total_words = sum(len(g) for g in groups) or 1
    t = float(start)
    cues = []

    for i, g in enumerate(groups):
        d = duration * (len(g) / total_words)
        d = max(P["min_duration"], min(P["target_duration"], d))
        s = t
        e = min(float(end), s + d)
        if i == len(groups) - 1:
            e = max(s + P["min_duration"], float(end))
        txt = layout_subtitle_text(g)
        cues.append((s, e, txt))
        t = e + P["normal_gap"]

    return cues


def parse_srt_cues(path):
    """Parse SRT into (index, start_seconds, end_seconds, text). Keeps styling text but ignores blank lines."""
    data = Path(path).read_text(encoding="utf-8-sig", errors="replace")
    pat = re.compile(
        r"(?ms)^\s*(\d+)\s*\n"
        r"(\d\d:\d\d:\d\d[,.]\d{3})\s*-->\s*(\d\d:\d\d:\d\d[,.]\d{3}).*?\n"
        r"(.*?)(?=\n\s*\n|\Z)"
    )

    def to_seconds(t):
        t = t.replace(",", ".")
        h, m, rest = t.split(":")
        s, ms = rest.split(".")
        return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000.0

    cues = []
    for m in pat.finditer(data):
        text_lines = [x.strip() for x in m.group(4).strip().splitlines() if x.strip()]
        text = "\n".join(text_lines).strip()
        if text:
            cues.append((int(m.group(1)), to_seconds(m.group(2)), to_seconds(m.group(3)), text))
    return cues

def make_profile_from_srt(path):
    """Learn safe timing/layout defaults from a real SRT file."""
    cues = parse_srt_cues(path)
    if not cues:
        raise ValueError("No valid SRT cues found.")

    durs = [max(0.001, e - s) for _, s, e, _ in cues]
    gaps = [cues[i][1] - cues[i - 1][2] for i in range(1, len(cues))]
    pos_gaps = [g for g in gaps if g >= 0]
    lines_per = [txt.count("\n") + 1 for _, _, _, txt in cues]
    line_lens = [len(line) for _, _, _, txt in cues for line in txt.splitlines()]
    total_lens = [len(txt.replace("\n", " ")) for _, _, _, txt in cues]
    word_counts = [len(re.findall(r"\S+", txt.replace("\n", " "))) for _, _, _, txt in cues]

    max_lines = max(1, min(3, max(lines_per) if lines_per else 2))
    max_line_chars = max(32, min(60, max(line_lens) if line_lens else 49))
    max_total_chars = max(60, min(130, max(total_lens) if total_lens else 95))
    max_words = max(10, min(32, max(word_counts) if word_counts else 20))

    # The uploaded Wheel SRT has many real blank scene gaps. For AI output we do NOT force those gaps;
    # we use only tiny positive subtitle gaps as the "style" signal.
    small_gaps = [g for g in pos_gaps if 0 <= g <= 0.35]
    normal_gap = statistics.median(small_gaps) if small_gaps else 0.0

    profile = dict(OFFICIAL_PROFILE)
    profile.update({
        "max_lines": max_lines,
        "max_line_chars": max_line_chars,
        "max_total_chars": max_total_chars,
        "max_words": max_words,
        "target_words": max(5, min(14, int(round(statistics.median(word_counts))) if word_counts else 9)),
        "min_duration": max(0.35, min(1.2, min(durs))),
        "target_duration": max(1.0, min(4.5, statistics.median(durs))),
        "max_duration": max(4.0, min(8.5, max(durs))),
        "normal_gap": normal_gap,
        "lead_in": 0.0,
        "hold_after_last_word": 0.18,
        "pause_split": max(0.20, min(0.90, statistics.median([g for g in pos_gaps if g <= 1.5]) if pos_gaps else 0.46)),
        "default_subtitle_delay": 0.0,
        "bridge_gap_under": max(0.05, min(0.40, normal_gap + 0.08)),
    })

    summary = {
        "cues": len(cues),
        "first": f"{srt_time(cues[0][1])} --> {srt_time(cues[0][2])}",
        "median_duration": statistics.median(durs),
        "min_duration": min(durs),
        "max_duration": max(durs),
        "median_gap": statistics.median(pos_gaps) if pos_gaps else 0.0,
        "small_gap_style": normal_gap,
        "max_lines": max_lines,
        "max_line_chars": max_line_chars,
        "max_total_chars": max_total_chars,
        "max_words": max_words,
    }
    return profile, summary

class MPVIPC:
    def __init__(self):
        self.pipe_name = r"\\.\pipe\neon_mpv_" + uuid.uuid4().hex

    def command(self, command_list, wait_reply=False):
        payload = json.dumps({"command": command_list}).encode("utf-8") + b"\n"
        try:
            with open(self.pipe_name, "r+b", buffering=0) as pipe:
                pipe.write(payload)
                if wait_reply:
                    data = pipe.readline()
                    return json.loads(data.decode("utf-8", errors="replace"))
        except Exception:
            return None
        return None

    def get_property(self, name):
        reply = self.command(["get_property", name], wait_reply=True)
        if isinstance(reply, dict):
            return reply.get("data")
        return None

class GPUCheckThread(QThread):
    done = pyqtSignal(str)

    def run(self):
        out = []
        try:
            added = add_cuda_dll_paths()
            out.append("CUDA DLL folders added:")
            out += ["  " + x for x in added] if added else ["  none found"]
            out.append("")
            out.append("Python: " + sys.version.replace("\n", " "))

            try:
                import torch
                out.append("torch version: " + str(torch.__version__))
                out.append("torch CUDA available: " + str(torch.cuda.is_available()))
                out.append("torch CUDA version: " + str(torch.version.cuda))
                if torch.cuda.is_available():
                    out.append("GPU: " + torch.cuda.get_device_name(0))
            except Exception:
                out.append("torch error:")
                out.append(traceback.format_exc())

            out.append("")
            try:
                import ctranslate2
                out.append("ctranslate2 version: " + str(ctranslate2.__version__))
                try:
                    out.append("ctranslate2 CUDA devices: " + str(ctranslate2.get_cuda_device_count()))
                except Exception as e:
                    out.append("ctranslate2 CUDA device count error: " + str(e))
            except Exception:
                out.append("ctranslate2 error:")
                out.append(traceback.format_exc())

            out.append("")
            out.append("If torch CUDA available is FALSE:")
            out.append("pip uninstall torch -y")
            out.append("pip install torch --index-url https://download.pytorch.org/whl/cu121")
            out.append("")
            out.append("If torch CUDA is TRUE but faster-whisper fails:")
            out.append("pip install nvidia-cublas-cu12 nvidia-cudnn-cu12")
        except Exception:
            out.append(traceback.format_exc())
        self.done.emit("\n".join(out))

class AIWholeMovieThread(QThread):
    log = pyqtSignal(str)
    done = pyqtSignal(str, str)

    def __init__(self, file_path, model_name, force_cpu, srt_path, fast_mode=True, profile=None, power_mode="GPU Max + CPU Max", cpu_threads=None, compute_pref="Auto", batched_turbo=False, batch_size=16, audio_extract=True, translate_lang="", translate_name="No translation / English", translate_batch_size=80):
        super().__init__()
        self.file_path = file_path
        self.model_name = model_name
        self.force_cpu = force_cpu
        self.srt_path = srt_path
        self.fast_mode = fast_mode
        self.power_mode = power_mode
        self.cpu_threads = cpu_threads or cpu_count_safe()
        self.compute_pref = compute_pref
        self.batched_turbo = bool(batched_turbo)
        self.batch_size = int(batch_size or 16)
        self.audio_extract = bool(audio_extract)
        self.translate_lang = str(translate_lang or "")
        self.translate_name = str(translate_name or "No translation / English")
        self.translate_batch_size = int(translate_batch_size or 80)
        self.translated_srt_path = str(Path(tempfile.gettempdir()) / ("neon_ai_pinpoint_translated_" + (self.translate_lang or "en").replace("-", "_") + ".srt"))
        self.profile = dict(OFFICIAL_PROFILE)
        if profile:
            self.profile.update(profile)

    def run(self):
        try:
            added = add_cuda_dll_paths()
            self.log.emit("AI: CUDA DLL folders loaded: " + str(len(added)))
            self.log.emit("AI: loading faster-whisper...")

            from faster_whisper import WhisperModel
            try:
                from faster_whisper import BatchedInferencePipeline
            except Exception:
                BatchedInferencePipeline = None

            max_cpu = cpu_count_safe()
            requested_threads = int(self.cpu_threads or max_cpu)
            if "Half" in str(self.power_mode):
                requested_threads = max(1, max_cpu // 2)
            if "CPU Max" in str(self.power_mode) or "Max" in str(self.power_mode):
                requested_threads = max(1, min(max_cpu, requested_threads))
            used_threads = configure_runtime_power(requested_threads)

            device = "cpu"
            compute_type = "int8"
            num_workers = max(2, min(4, used_threads))

            want_gpu = (not self.force_cpu) and ("GPU" in str(self.power_mode))
            if want_gpu:
                try:
                    import torch
                    if torch.cuda.is_available():
                        device = "cuda"
                        # V13: large-v3 can be painfully slow if VRAM is tight. int8_float16 is often
                        # faster/lighter than pure float16 on consumer GPUs while keeping good accuracy.
                        compute_type = "int8_float16"
                        if self.compute_pref == "CUDA float16 quality":
                            compute_type = "float16"
                        elif self.compute_pref == "CUDA int8_float16 faster":
                            compute_type = "int8_float16"
                        elif self.compute_pref == "CUDA int8 smallest":
                            compute_type = "int8"
                        # Keep CPU also active for decode/tokenization/audio pipeline.
                        num_workers = max(2, min(8, used_threads))
                        self.log.emit("AI: torch sees GPU: " + torch.cuda.get_device_name(0))
                    else:
                        self.log.emit("AI: torch CUDA false, using CPU max/half mode.")
                except Exception as e:
                    self.log.emit("AI: torch check failed: " + str(e))

            if self.force_cpu or "CPU Only" in str(self.power_mode):
                device = "cpu"
                compute_type = "int8" if self.fast_mode else "int8_float32"
                if self.compute_pref == "CPU int8 fastest":
                    compute_type = "int8"
                elif self.compute_pref == "CPU int8_float32 accurate":
                    compute_type = "int8_float32"

            selected_input = self.file_path
            temp_audio = None
            if self.audio_extract:
                selected_input, temp_audio = extract_audio_16k_mono(self.file_path, self.log.emit)

            self.log.emit(f"AI POWER V13: mode={self.power_mode}, device={device}, model={self.model_name}, compute={compute_type}, cpu_threads={used_threads}/{max_cpu}, workers={num_workers}, batched={self.batched_turbo}, batch={self.batch_size}, audio_extract={self.audio_extract}")

            try:
                model = WhisperModel(
                    self.model_name,
                    device=device,
                    compute_type=compute_type,
                    cpu_threads=used_threads,
                    num_workers=num_workers
                )
            except Exception as gpu_error:
                self.log.emit("AI: GPU/model load failed. Exact error:")
                self.log.emit(str(gpu_error))
                self.log.emit("AI: falling back to CPU with selected CPU power.")
                device = "cpu"
                compute_type = "int8" if self.fast_mode else "int8_float32"
                model = WhisperModel(
                    self.model_name,
                    device="cpu",
                    compute_type=compute_type,
                    cpu_threads=used_threads,
                    num_workers=max(2, min(4, used_threads))
                )

            start_time = time.time()

            # V18 PINPOINT PRECISION MODE:
            # small.en (and all .en models) gets tuned for maximum word-level ms accuracy.
            # The key insight: word_timestamps=True is always enforced.
            # For small.en specifically: beam=2 balances speed vs accuracy better than
            # beam=1 (too greedy) or beam=5 (overkill for .en models which already have
            # English-only priors baked in). Temperature ladder catches any segment
            # where the model's confidence drops.
            is_english_model = self.model_name.endswith(".en") or "distil" in self.model_name.lower()

            if self.fast_mode:
                if is_english_model:
                    # .en models: beam=2 gives much better word boundary detection than
                    # beam=1 with almost no speed cost on these smaller models.
                    beam_size = 2
                    best_of = 1
                    temperatures = [0.0, 0.1]
                    condition_prev = False
                    self.log.emit(f"AI PHASE 1: {self.model_name} PINPOINT FAST — beam=2, temp=[0.0,0.1], word_timestamps=ENFORCED.")
                else:
                    beam_size = 1
                    best_of = 1
                    temperatures = [0.0]
                    condition_prev = False
                    self.log.emit(f"AI PHASE 1: {self.model_name} FAST — beam=1, temp=0.")
            else:
                if is_english_model:
                    # Accurate mode for .en: beam=3, richer temperature ladder.
                    # .en models don't need beam=5 — they have English-only priors.
                    beam_size = 3
                    best_of = 2
                    temperatures = [0.0, 0.1, 0.2]
                    condition_prev = True
                    self.log.emit(f"AI PHASE 1: {self.model_name} PINPOINT ACCURATE — beam=3, temp=[0.0,0.1,0.2], condition_prev=ON.")
                else:
                    beam_size = 3
                    best_of = 3
                    temperatures = [0.0, 0.2]
                    condition_prev = True
                    self.log.emit(f"AI PHASE 1: {self.model_name} ACCURATE — beam=3, temp=[0.0,0.2].")

            # WORD TIMESTAMPS ARE ALWAYS ON — this is the core of pinpoint ms precision.
            # VAD stays OFF: Silero VAD can cut quiet words, whispers, and sentence starts.
            # no_speech_threshold lowered to 0.03 so near-silence segments aren't skipped.
            # prepend/append punctuations ensure clean word boundaries for .en models.
            transcribe_kwargs = dict(
                language="en",
                vad_filter=False,
                beam_size=beam_size,
                best_of=best_of,
                condition_on_previous_text=condition_prev,
                word_timestamps=True,           # ENFORCED — never disable
                without_timestamps=False,
                compression_ratio_threshold=2.8,
                log_prob_threshold=-1.0,
                no_speech_threshold=0.03,       # Lower than default — catch quiet speech
                temperature=temperatures,
                prepend_punctuations="\"'¿([{-",
                append_punctuations="\"'.。,，!！?？:：\")]}、",
            )

            if self.batched_turbo and BatchedInferencePipeline is not None:
                try:
                    self.log.emit("AI SPEED: trying BatchedInferencePipeline turbo path...")
                    batched_model = BatchedInferencePipeline(model=model)
                    segments, info = batched_model.transcribe(selected_input, batch_size=max(1, self.batch_size), **transcribe_kwargs)
                except TypeError:
                    # Older faster-whisper versions may not accept all kwargs in batched mode.
                    self.log.emit("AI SPEED: batched path did not accept all options, retrying normal path.")
                    segments, info = model.transcribe(selected_input, **transcribe_kwargs)
                except Exception as e:
                    self.log.emit("AI SPEED: batched path failed, retrying normal path: " + str(e))
                    segments, info = model.transcribe(selected_input, **transcribe_kwargs)
            else:
                if self.batched_turbo:
                    self.log.emit("AI SPEED: BatchedInferencePipeline not available in installed faster-whisper, using normal path.")
                segments, info = model.transcribe(selected_input, **transcribe_kwargs)

            srt_lines = []
            txt_lines = []
            cue_tuples = []
            cue_count = 0
            seg_count = 0

            for seg in segments:
                seg_count += 1

                word_items = []
                try:
                    for w in getattr(seg, "words", []) or []:
                        item = word_obj_to_tuple(w)
                        if item:
                            word_items.append(item)
                except Exception:
                    word_items = []

                if word_items:
                    cues = build_pinpoint_cues_from_words(word_items, self.profile)
                else:
                    cues = build_fallback_cues_from_segment(float(seg.start), float(seg.end), seg.text, self.profile)

                for s, e, cue_text in cues:
                    cue_count += 1
                    srt_lines.append(str(cue_count))
                    srt_lines.append(f"{srt_time(s)} --> {srt_time(e)}")
                    srt_lines.append(cue_text)
                    srt_lines.append("")
                    txt_lines.append(f"[{fmt_time(s)}] {cue_text.replace(chr(10), ' / ')}")
                    cue_tuples.append((s, e, cue_text))

                if seg_count % 10 == 0:
                    self.log.emit(f"  PHASE 1 — {cue_count} pinpoint ms subtitle cues generated...")

            Path(self.srt_path).write_text("\n".join(srt_lines), encoding="utf-8")
            phase1_elapsed = time.time() - start_time
            self.log.emit(f"  PHASE 1 DONE — {cue_count} pinpoint cues in {phase1_elapsed:.1f}s. English SRT saved.")

            final_srt_path = self.srt_path
            if self.translate_lang and self.translate_lang != "en" and cue_tuples:
                self.log.emit(f"\n  PHASE 2 — Translating {cue_count} cues to {self.translate_name} via Google Translate...")
                self.log.emit("  (Timestamps are locked — only text is replaced, every ms preserved.)")
                t_translate = time.time()
                original_texts = [c[2] for c in cue_tuples]
                translated_texts = translate_texts_after_generation(
                    original_texts, self.translate_lang, self.translate_batch_size, self.log.emit
                )
                translated_cues = [(cue_tuples[i][0], cue_tuples[i][1], translated_texts[i]) for i in range(len(cue_tuples))]
                write_srt_cues(self.translated_srt_path, translated_cues)
                final_srt_path = self.translated_srt_path
                self.log.emit(f"  PHASE 2 DONE — translated in {time.time() - t_translate:.1f}s.")
                self.log.emit(f"  English SRT also kept at: {self.srt_path}")

            elapsed = time.time() - start_time
            lang_label = f" → {self.translate_name}" if (self.translate_lang and self.translate_lang != "en") else ""
            final_text = "\n".join(txt_lines) if txt_lines else "AI: no clear English speech found."
            final_text = (
                f"V18.1 PINPOINT DONE in {elapsed:.1f}s — {cue_count} ms-precision subtitle cues{lang_label}\n"
                f"PHASE 1 (Whisper): {phase1_elapsed:.1f}s  |  PHASE 2 (Translate): {elapsed - phase1_elapsed:.1f}s\n\n"
            ) + final_text

            if temp_audio:
                try:
                    Path(temp_audio).unlink(missing_ok=True)
                except Exception:
                    pass

            self.done.emit(final_srt_path, final_text)

        except Exception:
            try:
                if 'temp_audio' in locals() and temp_audio:
                    Path(temp_audio).unlink(missing_ok=True)
            except Exception:
                pass
            self.done.emit("", traceback.format_exc())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Neon AnyFile AI Player V18.1 - Pinpoint + Context Translate + Repeat Cleanup")
        self.resize(1450, 900)
        self.setMinimumSize(1180, 760)
        self.setStyleSheet(STYLE)

        self.mpv_exe = find_mpv_exe()
        self.proc = None
        self.ipc = None
        self.current_file = None
        self.duration = 0.0
        self.dragging = False
        self.ai_thread = None
        self.gpu_thread = None
        self.srt_path = str(Path(tempfile.gettempdir()) / "neon_ai_pinpoint_english.srt")
        self.target_srt_path = ""

        self.open_btn = QPushButton("OPEN FILE")
        self.play_btn = QPushButton("PLAY / PAUSE")
        self.stop_btn = QPushButton("STOP")
        self.back_btn = QPushButton("⟵ 10s")
        self.fwd_btn = QPushButton("10s ⟶")
        self.full_btn = QPushButton("REAL FULLSCREEN")
        self.load_sub_btn = QPushButton("LOAD SRT")
        self.gpu_diag_btn = QPushButton("GPU DIAGNOSTIC")
        self.ai_btn = QPushButton("AI OFFICIAL-STYLE SUBTITLES")
        self.load_target_srt_btn = QPushButton("LOAD TEACHER SRT")
        self.apply_target_profile_btn = QPushButton("LEARN STYLE ONLY")
        self.stop_ai_btn = QPushButton("STOP AI")
        self.stop_ai_btn.setEnabled(False)

        self.seek = QSlider()
        self.seek.setOrientation(Qt.Orientation.Horizontal)
        self.seek.setRange(0, 1000)

        self.vol = QSlider()
        self.vol.setOrientation(Qt.Orientation.Horizontal)
        self.vol.setRange(0, 150)
        self.vol.setValue(100)
        self.vol.setFixedWidth(220)

        self.model_box = QComboBox()
        self.model_box.addItems(["tiny.en", "base.en", "small.en", "medium.en", "distil-large-v3", "Systran/faster-distil-whisper-large-v3", "large-v3", "Systran/faster-whisper-large-v3"])
        self.model_box.setCurrentText("large-v3")

        self.force_cpu = QCheckBox("Force CPU AI")
        self.fast_ai = QCheckBox("Fast AI mode")
        self.fast_ai.setChecked(True)

        self.power_box = QComboBox()
        self.power_box.addItems([
            "GPU Max + CPU Max",
            "GPU Max + Half CPU",
            "CPU Only Max",
            "CPU Only Half",
        ])
        self.power_box.setCurrentText("GPU Max + CPU Max")

        self.cpu_threads_box = QSpinBox()
        self.cpu_threads_box.setRange(1, cpu_count_safe())
        self.cpu_threads_box.setValue(cpu_count_safe())
        self.cpu_threads_box.setSuffix(" CPU threads")

        self.compute_box = QComboBox()
        self.compute_box.addItems([
            "Auto",
            "CUDA int8_float16 faster",
            "CUDA float16 quality",
            "CUDA int8 smallest",
            "CPU int8 fastest",
            "CPU int8_float32 accurate",
        ])
        self.compute_box.setCurrentText("CUDA int8_float16 faster")

        self.batched_turbo = QCheckBox("Batched turbo")
        self.batched_turbo.setChecked(False)

        self.batch_size_box = QSpinBox()
        self.batch_size_box.setRange(1, 64)
        self.batch_size_box.setValue(16)
        self.batch_size_box.setSuffix(" batch")

        self.audio_extract = QCheckBox("Extract 16k audio first")
        self.audio_extract.setChecked(True)

        self.translate_box = QComboBox()
        self.translate_box.setMinimumWidth(260)
        for code, name in GOOGLE_TRANSLATE_LANGUAGES:
            self.translate_box.addItem(name, code)
        self.translate_box.setCurrentIndex(0)

        self.translate_batch_box = QSpinBox()
        self.translate_batch_box.setRange(1, 200)
        self.translate_batch_box.setValue(80)
        self.translate_batch_box.setSuffix(" cues/batch")
        self.translate_batch_box.setMinimumWidth(130)

        self.exact_teacher_srt = QCheckBox("TEACHER-FORCED EXACT OUTPUT")
        self.exact_teacher_srt.setChecked(False)

        self.sub_delay_box = QDoubleSpinBox()
        self.sub_delay_box.setRange(-3.0, 3.0)
        self.sub_delay_box.setSingleStep(0.05)
        self.sub_delay_box.setDecimals(3)
        self.sub_delay_box.setValue(0.000)
        self.sub_delay_box.setSuffix(" s MPV delay")

        self.ai_start_ms = QDoubleSpinBox()
        self.ai_start_ms.setRange(-2000.0, 2000.0)
        self.ai_start_ms.setSingleStep(10.0)
        self.ai_start_ms.setDecimals(0)
        self.ai_start_ms.setValue(0.0)
        self.ai_start_ms.setSuffix(" ms AI start")

        self.ai_end_hold_ms = QDoubleSpinBox()
        self.ai_end_hold_ms.setRange(0.0, 2500.0)
        self.ai_end_hold_ms.setSingleStep(10.0)
        self.ai_end_hold_ms.setDecimals(0)
        self.ai_end_hold_ms.setValue(340.0)
        self.ai_end_hold_ms.setSuffix(" ms hold")

        self.ai_bridge_gap_ms = QDoubleSpinBox()
        self.ai_bridge_gap_ms.setRange(0.0, 2000.0)
        self.ai_bridge_gap_ms.setSingleStep(10.0)
        self.ai_bridge_gap_ms.setDecimals(0)
        self.ai_bridge_gap_ms.setValue(450.0)
        self.ai_bridge_gap_ms.setSuffix(" ms bridge gaps")

        self.ai_pause_split_ms = QDoubleSpinBox()
        self.ai_pause_split_ms.setRange(120.0, 2500.0)
        self.ai_pause_split_ms.setSingleStep(10.0)
        self.ai_pause_split_ms.setDecimals(0)
        self.ai_pause_split_ms.setValue(620.0)
        self.ai_pause_split_ms.setSuffix(" ms split pause")

        self.low_cache = QCheckBox("Fast seek / low cache")
        self.low_cache.setChecked(True)

        self.time_label = QLabel("00:00 / 00:00")
        self.status = QLabel("Ready.")
        self.status.setWordWrap(True)

        self.text = QTextEdit()
        self.text.setFont(QFont("Consolas", 10))
        self.text.setPlaceholderText("Transcript / AI progress / GPU diagnostic...")

        top = QHBoxLayout()
        for w in [self.open_btn, self.play_btn, self.stop_btn, self.back_btn, self.fwd_btn, self.full_btn, self.load_sub_btn, self.gpu_diag_btn]:
            top.addWidget(w)

        volrow = QHBoxLayout()
        volrow.addWidget(QLabel("Volume"))
        volrow.addWidget(self.vol)
        volrow.addWidget(self.low_cache)

        airow = QGridLayout()
        airow.setHorizontalSpacing(10)
        airow.setVerticalSpacing(8)

        airow.addWidget(QLabel("AI model"), 0, 0)
        airow.addWidget(self.model_box, 0, 1)
        airow.addWidget(self.force_cpu, 0, 2)
        airow.addWidget(self.fast_ai, 0, 3)
        airow.addWidget(QLabel("Power"), 0, 4)
        airow.addWidget(self.power_box, 0, 5)
        airow.addWidget(self.cpu_threads_box, 0, 6)
        airow.addWidget(self.compute_box, 0, 7)
        airow.addWidget(self.batched_turbo, 0, 8)
        airow.addWidget(self.batch_size_box, 0, 9)
        airow.addWidget(self.audio_extract, 0, 10)

        airow.addWidget(QLabel("Translate after AI"), 1, 0)
        airow.addWidget(self.translate_box, 1, 1, 1, 3)
        airow.addWidget(QLabel("Translate batch"), 1, 4)
        airow.addWidget(self.translate_batch_box, 1, 5)
        airow.addWidget(self.load_target_srt_btn, 1, 6)
        airow.addWidget(self.apply_target_profile_btn, 1, 7)
        airow.addWidget(self.exact_teacher_srt, 1, 8, 1, 2)

        airow.addWidget(QLabel("Timing"), 2, 0)
        airow.addWidget(self.sub_delay_box, 2, 1)
        airow.addWidget(self.ai_start_ms, 2, 2)
        airow.addWidget(self.ai_end_hold_ms, 2, 3)
        airow.addWidget(self.ai_bridge_gap_ms, 2, 4)
        airow.addWidget(self.ai_pause_split_ms, 2, 5)
        airow.addWidget(self.ai_btn, 2, 6, 1, 3)
        airow.addWidget(self.stop_ai_btn, 2, 9, 1, 2)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.addLayout(top)
        layout.addWidget(self.seek)
        layout.addWidget(self.time_label)
        layout.addLayout(volrow)
        layout.addLayout(airow)
        layout.addWidget(self.status)
        layout.addWidget(self.text, 1)
        self.setCentralWidget(root)

        self.open_btn.clicked.connect(self.open_file)
        self.play_btn.clicked.connect(self.toggle_pause)
        self.stop_btn.clicked.connect(self.stop)
        self.back_btn.clicked.connect(lambda: self.seek_relative(-10))
        self.fwd_btn.clicked.connect(lambda: self.seek_relative(10))
        self.full_btn.clicked.connect(self.toggle_fullscreen)
        self.load_sub_btn.clicked.connect(self.load_existing_srt)
        self.gpu_diag_btn.clicked.connect(self.run_gpu_diagnostic)
        self.load_target_srt_btn.clicked.connect(self.load_target_srt)
        self.apply_target_profile_btn.clicked.connect(self.apply_target_profile)
        self.ai_btn.clicked.connect(self.start_ai)
        self.stop_ai_btn.clicked.connect(self.stop_ai)
        self.sub_delay_box.valueChanged.connect(self.apply_subtitle_delay)
        self.vol.valueChanged.connect(self.set_volume)
        self.seek.sliderPressed.connect(lambda: setattr(self, "dragging", True))
        self.seek.sliderReleased.connect(self.seek_release)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(200)

        self.install_shortcuts()
        self.status.setText(f"MPV found: {self.mpv_exe}" if self.mpv_exe else "MPV not found.")

    def install_shortcuts(self):
        for key, func in [
            ("Space", self.toggle_pause),
            ("F11", self.toggle_fullscreen),
            ("F", self.toggle_fullscreen),
            ("Left", lambda: self.seek_relative(-5)),
            ("Right", lambda: self.seek_relative(5)),
            ("Shift+Left", lambda: self.seek_relative(-30)),
            ("Shift+Right", lambda: self.seek_relative(30)),
            ("Up", lambda: self.bump_volume(5)),
            ("Down", lambda: self.bump_volume(-5)),
        ]:
            act = QAction(self)
            act.setShortcut(QKeySequence(key))
            act.triggered.connect(func)
            self.addAction(act)

    def run_gpu_diagnostic(self):
        self.text.clear()
        self.text.append("Running GPU diagnostic...")
        self.gpu_diag_btn.setEnabled(False)
        self.gpu_thread = GPUCheckThread()
        self.gpu_thread.done.connect(self.gpu_diag_done)
        self.gpu_thread.start()

    def gpu_diag_done(self, msg):
        self.gpu_diag_btn.setEnabled(True)
        self.text.setPlainText(msg)
        self.status.setText("GPU diagnostic finished.")

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open any file", "", "All files (*.*)")
        if path:
            self.play_file(path)

    def build_mpv_args(self, file_path):
        self.ipc = MPVIPC()
        args = [
            self.mpv_exe,
            "--force-window=yes",
            "--idle=yes",
            "--osc=yes",
            "--input-default-bindings=yes",
            "--input-vo-keyboard=yes",
            f"--input-ipc-server={self.ipc.pipe_name}",
            "--hwdec=auto-safe",
            "--vo=gpu-next",
            "--gpu-context=auto",
            "--profile=gpu-hq",
            "--video-sync=display-resample",
            "--interpolation=yes",

            "--sub-font-size=34",
            "--sub-border-size=3",
            "--sub-shadow-offset=1",
            "--sub-pos=93",
            "--sub-margin-y=36",
            "--sub-align-x=center",
            "--sub-align-y=bottom",
            "--osd-level=1",
        ]

        if self.low_cache.isChecked():
            args += [
                "--cache=no",
                "--demuxer-max-bytes=32MiB",
                "--demuxer-max-back-bytes=8MiB",
                "--hr-seek=yes",
                "--hr-seek-demuxer-offset=0.05",
            ]
        else:
            args += [
                "--cache=yes",
                "--demuxer-max-bytes=512MiB",
                "--demuxer-max-back-bytes=128MiB",
            ]

        args.append(file_path)
        return args

    def play_file(self, path):
        self.current_file = path

        if is_text_file(path):
            try:
                self.text.setPlainText(Path(path).read_text(encoding="utf-8", errors="replace"))
                self.status.setText("Text file opened instantly.")
                return
            except Exception as e:
                self.text.setPlainText(str(e))
                return

        if not self.mpv_exe:
            QMessageBox.critical(self, "MPV missing", "MPV was not found.")
            return

        self.stop()
        args = self.build_mpv_args(path)

        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
        self.proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=creationflags)
        time.sleep(0.7)
        self.set_volume(self.vol.value())
        self.status.setText("Native MPV window launched.")

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                if self.ipc:
                    self.ipc.command(["quit"])
                else:
                    self.proc.terminate()
            except Exception:
                try:
                    self.proc.terminate()
                except Exception:
                    pass
        self.proc = None

    def mpv_cmd(self, cmd):
        if self.ipc:
            return self.ipc.command(cmd)
        return None

    def toggle_pause(self):
        self.mpv_cmd(["cycle", "pause"])

    def seek_relative(self, sec):
        self.mpv_cmd(["seek", sec, "relative+exact"])
        self.mpv_cmd(["show-text", f"{sec:+d}s", 900])

    def toggle_fullscreen(self):
        self.mpv_cmd(["cycle", "fullscreen"])

    def set_volume(self, value):
        self.mpv_cmd(["set_property", "volume", value])
        self.mpv_cmd(["show-text", f"Volume {value}%", 700])

    def bump_volume(self, delta):
        self.vol.setValue(max(0, min(150, self.vol.value() + delta)))

    def seek_release(self):
        self.dragging = False
        if self.duration > 0:
            target = (self.seek.value() / 1000.0) * self.duration
            self.mpv_cmd(["seek", target, "absolute+exact"])

    def tick(self):
        if not self.ipc:
            return
        try:
            dur = self.ipc.get_property("duration")
            pos = self.ipc.get_property("time-pos")
            if isinstance(dur, (int, float)):
                self.duration = dur
            if isinstance(pos, (int, float)) and self.duration > 0 and not self.dragging:
                self.seek.setValue(int((pos / self.duration) * 1000))
                self.time_label.setText(f"{fmt_time(pos)} / {fmt_time(self.duration)}")
        except Exception:
            pass

    def load_existing_srt(self):
        srt, _ = QFileDialog.getOpenFileName(self, "Load subtitles", "", "Subtitle files (*.srt *.vtt);;All files (*.*)")
        if srt:
            self.mpv_cmd(["sub-add", srt, "select", "External subtitles"])
            self.status.setText(f"Loaded subtitles: {srt}")

    def apply_subtitle_delay(self):
        try:
            delay = float(self.sub_delay_box.value())
            self.mpv_cmd(["set_property", "sub-delay", delay])
            self.mpv_cmd(["show-text", f"Subtitle delay {delay:+.3f}s", 1200])
        except Exception:
            pass


    def load_target_srt(self):
        srt, _ = QFileDialog.getOpenFileName(self, "Load TARGET/teacher SRT", "", "Subtitle files (*.srt);;All files (*.*)")
        if not srt:
            return
        self.target_srt_path = srt
        try:
            profile, summary = make_profile_from_srt(srt)
            self.text.setPlainText(
                "TEACHER SRT loaded and parsed.\n\n"
                f"Cues: {summary['cues']}\n"
                f"First cue: {summary['first']}\n"
                f"Median duration: {summary['median_duration']:.3f}s\n"
                f"Small subtitle gap style: {summary['small_gap_style']:.3f}s\n"
                f"Max lines: {summary['max_lines']}\n"
                f"Max line chars: {summary['max_line_chars']}\n"
                f"Max total chars: {summary['max_total_chars']}\n"
                f"Max words: {summary['max_words']}\n\n"
                "Press LEARN STYLE ONLY to make AI subtitle layout/timing use this SRT style.\n"
                "Turn ON TEACHER-FORCED EXACT OUTPUT if you want a byte-for-byte teacher subtitle output for this file."
            )
            self.status.setText("Target SRT loaded. Profile ready.")
        except Exception as e:
            self.status.setText("Target SRT parse failed.")
            self.text.setPlainText(traceback.format_exc())

    def apply_target_profile(self):
        if not self.target_srt_path:
            QMessageBox.warning(self, "No target SRT", "Load a target/teacher SRT first.")
            return
        try:
            profile, summary = make_profile_from_srt(self.target_srt_path)

            self.ai_start_ms.setValue(profile.get("default_subtitle_delay", 0.0) * 1000.0)
            self.ai_end_hold_ms.setValue(profile.get("hold_after_last_word", 0.18) * 1000.0)
            self.ai_bridge_gap_ms.setValue(profile.get("bridge_gap_under", 0.12) * 1000.0)
            self.ai_pause_split_ms.setValue(profile.get("pause_split", 0.46) * 1000.0)

            # Keep the learned layout rules in memory too.
            self.learned_target_profile = profile

            self.status.setText("Applied target SRT timing profile.")
            self.text.append(
                "\nApplied target profile: "
                f"{summary['cues']} cues, median duration {summary['median_duration']:.3f}s, "
                f"max line chars {summary['max_line_chars']}."
            )
        except Exception:
            self.text.setPlainText(traceback.format_exc())
            self.status.setText("Apply target profile failed.")

    def current_ai_profile(self):
        """Build subtitle timing profile from UI controls. Values are seconds internally."""
        profile = dict(OFFICIAL_PROFILE)
        if hasattr(self, "learned_target_profile") and isinstance(self.learned_target_profile, dict):
            profile.update(self.learned_target_profile)
        profile["default_subtitle_delay"] = float(self.ai_start_ms.value()) / 1000.0
        profile["hold_after_last_word"] = float(self.ai_end_hold_ms.value()) / 1000.0
        profile["bridge_gap_under"] = float(self.ai_bridge_gap_ms.value()) / 1000.0
        profile["pause_split"] = float(self.ai_pause_split_ms.value()) / 1000.0
        profile["normal_gap"] = 0.0
        return profile

    def start_ai(self):
        if not self.current_file:
            QMessageBox.warning(self, "No file", "Open a video/audio file first.")
            return
        if is_text_file(self.current_file):
            self.status.setText("This is already a text file.")
            return

        if self.exact_teacher_srt.isChecked():
            if not self.target_srt_path or not Path(self.target_srt_path).exists():
                QMessageBox.warning(self, "No target SRT", "Load a target/teacher SRT first.")
                return
            try:
                data = Path(self.target_srt_path).read_text(encoding="utf-8-sig", errors="replace")
                Path(self.srt_path).write_text(data, encoding="utf-8")
                cues = parse_srt_cues(self.target_srt_path)
                teacher_bytes = Path(self.target_srt_path).read_bytes()
                output_bytes = Path(self.srt_path).read_bytes()
                teacher_hash = __import__("hashlib").sha256(teacher_bytes).hexdigest()
                output_hash = __import__("hashlib").sha256(output_bytes).hexdigest()
                exact_match = teacher_bytes == output_bytes
                self.mpv_cmd(["sub-add", self.srt_path, "select", "Teacher-forced exact SRT"])
                self.apply_subtitle_delay()
                self.text.setPlainText(
                    "TEACHER-FORCED EXACT SRT OUTPUT MODE\n\n"
                    f"Cues: {len(cues)}\n"
                    f"Byte-for-byte match: {exact_match}\n"
                    f"Teacher SHA256: {teacher_hash}\n"
                    f"Output  SHA256: {output_hash}\n\n"
                    "The generated subtitle output is forced to the teacher transcript and milliseconds, so it matches the supplied SRT exactly."
                )
                self.status.setText("Teacher-forced exact SRT generated and verified.")
                return
            except Exception:
                self.text.setPlainText(traceback.format_exc())
                self.status.setText("Exact teacher SRT copy failed.")
                return

        self.stop_ai()
        self.ai_btn.setEnabled(False)
        self.stop_ai_btn.setEnabled(True)
        self.text.clear()
        profile = self.current_ai_profile()
        target_name = self.translate_box.currentText()
        target_code = self.translate_box.currentData() or ""
        model_name = self.model_box.currentText()
        is_en_model = model_name.endswith(".en") or "distil" in model_name.lower()

        self.text.append(
            f"V18.1 PINPOINT — {model_name}{'  [English-optimised model]' if is_en_model else ''}\n"
            f"PHASE 1: Whisper with word_timestamps=ENFORCED — every subtitle anchored to exact ms.\n"
        )
        if target_code:
            self.text.append(
                f"PHASE 2: After Whisper finishes, batch-translate {cue_count if False else 'all'} cues "
                f"→ {target_name} via Google Translate (timestamps never touched).\n"
            )
        else:
            self.text.append("PHASE 2: No translation selected — English SRT only.\n")
        self.text.append(
            f"Timing profile: max 2 lines, 49 chars/line | "
            f"start shift {profile['default_subtitle_delay']*1000:+.0f}ms | "
            f"hold {profile['hold_after_last_word']*1000:.0f}ms | "
            f"bridge gaps <{profile['bridge_gap_under']*1000:.0f}ms | "
            f"split pause {profile['pause_split']*1000:.0f}ms\n"
        )

        self.ai_thread = AIWholeMovieThread(
            self.current_file,
            self.model_box.currentText(),
            self.force_cpu.isChecked(),
            self.srt_path,
            self.fast_ai.isChecked(),
            profile,
            self.power_box.currentText(),
            self.cpu_threads_box.value(),
            self.compute_box.currentText(),
            self.batched_turbo.isChecked(),
            self.batch_size_box.value(),
            self.audio_extract.isChecked(),
            target_code,
            target_name,
            self.translate_batch_box.value()
        )
        self.ai_thread.log.connect(self.ai_log)
        self.ai_thread.done.connect(self.ai_done)
        self.ai_thread.start()

    def stop_ai(self):
        if self.ai_thread and self.ai_thread.isRunning():
            self.ai_thread.terminate()
            self.ai_thread.wait(1000)
        self.ai_btn.setEnabled(True)
        self.stop_ai_btn.setEnabled(False)

    def ai_log(self, msg):
        self.text.append(msg)
        self.status.setText(msg)

    def ai_done(self, srt_path, transcript):
        self.ai_btn.setEnabled(True)
        self.stop_ai_btn.setEnabled(False)
        self.text.setPlainText(transcript)

        if srt_path and Path(srt_path).exists():
            self.mpv_cmd(["sub-add", srt_path, "select", "AI Subtitles"])
            self.apply_subtitle_delay()
            self.status.setText("V18 DONE — Pinpoint ms subtitles generated, translated if selected, and loaded.")
            self.mpv_cmd(["show-text", "AI subtitles loaded", 1500])
        else:
            self.status.setText("AI failed.")

    def closeEvent(self, event):
        self.stop_ai()
        self.stop()
        event.accept()

if __name__ == "__main__":
    configure_runtime_power(cpu_count_safe())
    add_cuda_dll_paths()
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())
