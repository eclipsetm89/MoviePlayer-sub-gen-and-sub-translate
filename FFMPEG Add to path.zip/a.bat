@echo off
echo Adding C:\FFMPEG to system PATH...

setx PATH "%PATH%;C:\FFMPEG" /M

echo.
echo Done.
echo Restart your terminal or programs to use ffmpeg globally.
pause
